"""
Playwright (pytest-playwright) port of the Robot Framework test case:

    core-tests/component/analytics/combined.robot
    -> "Combined Metric Computed From Aligned Inputs"

Original intent (preserved verbatim in assertions):
  Ingest two *aligned* input samples (metric A = 10.0, metric B = 20.0 at the
  SAME timestamp) for SIM_ID1. Levski computes the combined metric
  "AverageOfTwo" = (A + B) / 2 = 15.0 and writes it to the Cassandra
  analytics.short_term table. The test verifies that short_term contains
  A, B and AverageOfTwo for that (id, week, timestamp), then tears down by
  deleting the ingested short_term rows and clearing the misaligned-timestamp
  log state.

This is a backend data-pipeline test, not a browser/UI test, so Playwright's
APIRequestContext is the natural entry point and the non-HTTP integrations
(Kafka producer, Cassandra client, Levski REPL) are implemented as helpers
exactly as the conversion rules require.

Every Robot assertion maps to an assertion here:
  * Robot `Should Not Be Empty`        -> expect_value(...).not_to_be_empty()
  * Robot `Should Be Equal As Numbers` -> expect_value(...).to_equal_as_number(...)
  * Robot `list should contain ...`    -> expect_value(...).to_contain(...)
  * Robot `Pass Execution If`          -> pytest.skip (same pass/skip semantics)
"""

import pytest
from playwright.sync_api import APIRequestContext

from helpers.analytics_keywords import (
    AnalyticsBackend,
    current_time_in_milliseconds,
    week_for_epoch_time,
    make_sample,
    combine_lists,
)
from helpers.expect_value import expect_value

# --- Suite-level variables (from combined.robot *** Variables ***) ---
COMBINED_METRIC = "AverageOfTwo"
CASSANDRA_FIELDS = ["id", "idfamily", "week", "timestamp", "metric", "vdouble", "vlong", "vtext"]
COMBINED_METRIC_TOTAL_WAIT = "2 min"          # 120 s
COMBINED_METRIC_INCREMENTAL_STEP = "10 sec"   # 10 s poll interval
SIM_ID1 = "vm1"                               # Initialize Suite Variables -> vm1


@pytest.fixture(scope="module")
def backend(playwright):
    """
    Equivalent of combined.robot `Suite Setup` / `Suite Teardown`.

    Setup For Suite:
      - Connect to Zookeeper and Levski (REPL)
      - Connect To Full Fault
      - Truncate preexisting short_term rows
      - Initialize Suite Variables (SIM_ID1..3, combined/tca configs)
      - Insert Combined Metric Config On Cassandra
      - Load Combined Metric Config In Levski

    Teardown For Suite:
      - Cleanup (delete combined/tca configs)
      - Load Combined Metric Config In Levski
      - disconnect from levski / fault
    """
    request: APIRequestContext = playwright.request.new_context()
    be = AnalyticsBackend(request)

    # --- Suite Setup ---
    # If any setup step fails, still release the REPL connections before
    # propagating. pytest only runs the post-yield teardown when setup got past
    # `yield`, so without this a mid-setup failure would leak the server-side
    # REPL session and make the next run fail with "Already connected.".
    try:
        be.connect_to_zookeeper_and_levski()
        be.connect_to_full_fault()
        be.truncate_all_preexisting_rows_from_cassandra_short_term_table()
        be.initialize_suite_variables()
        be.insert_combined_metric_config_on_cassandra()
        be.load_combined_metric_config_in_levski()
    except Exception:
        try:
            be.disconnect()
        finally:
            request.dispose()
        raise

    yield be

    # --- Suite Teardown ---
    be.cleanup()
    be.load_combined_metric_config_in_levski()
    be.disconnect()
    request.dispose()


@pytest.mark.sanity
def test_combined_metric_computed_from_aligned_inputs(backend: AnalyticsBackend):
    """Combined Metric Computed From Aligned Inputs   [Tags] sanity"""
    # ${timestamp}=    Current Time In Milliseconds
    timestamp = current_time_in_milliseconds()
    # ${week}=  Week For Epoch Time  ${timestamp}
    week = week_for_epoch_time(timestamp)
    # ${short_term_metric_check_list}=  create list  A  B  AverageOfTwo
    short_term_metric_check_list = ["A", "B", "AverageOfTwo"]

    # Pass If Combined Metrics Disabled  ->  Pass Execution If ${disabled}
    if backend.combined_metrics_disabled():
        pytest.skip("combined metrics disabled in levski")

    # ${sample1}=    Make Sample  ${SIM_ID1}  A  ${timestamp}  10.0
    sample1 = make_sample(SIM_ID1, "A", timestamp, 10.0)
    # ${sample2}=    Make Sample  ${SIM_ID1}  B  ${timestamp}  20.0
    sample2 = make_sample(SIM_ID1, "B", timestamp, 20.0)
    # @{samples}=    Combine Lists  ${sample1}  ${sample2}
    samples = combine_lists(sample1, sample2)

    # Ingest Input Samples  ${samples}  ${timestamp}  ${short_term_metric_check_list}
    #   -> send to Kafka, then poll short_term for A, B, AverageOfTwo
    ingested_metrics = backend.ingest_input_samples(
        samples, timestamp, short_term_metric_check_list
    )
    # Robot: `list should contain deep sub list` inside Check Short Term Table Values
    for expected_metric in short_term_metric_check_list:
        expect_value(ingested_metrics).to_contain(expected_metric)

    try:
        # Wait Until Keyword Succeeds  2 min  10 sec
        #   Check ShortTerm Contains Combined Metric  ${SIM_ID1}  ${timestamp}  ${week}
        response = backend.wait_until_keyword_succeeds(
            COMBINED_METRIC_TOTAL_WAIT,
            COMBINED_METRIC_INCREMENTAL_STEP,
            backend.check_short_term_contains_combined_metric,
            SIM_ID1,
            timestamp,
            week,
        )
        # Robot keyword asserts `Should Not Be Empty  ${response}`
        expect_value(response).not_to_be_empty()

        # The combined metric AverageOfTwo = (10.0 + 20.0) / 2 = 15.0.
        combined_row = next(r for r in response if r["metric"] == COMBINED_METRIC)
        expect_value(combined_row["vdouble"]).to_equal_as_number(15.0)
    finally:
        # [Teardown]  Teardown For Tests  ${SIM_ID1}  ${timestamp}  ${timestamp}
        backend.teardown_for_tests(SIM_ID1, timestamp, timestamp)


# =========================================================================
# CI/CD INTEGRATION — GitHub Actions
# =========================================================================
# jobs:
#   combined-metric:
#     runs-on: ubuntu-latest
#     steps:
#       - uses: actions/checkout@v4
#       - uses: actions/setup-python@v5
#         with: { python-version: "3.11" }
#       - name: Install dependencies
#         run: |
#           pip install -r playwright_combined/requirements.txt
#           python -m playwright install --with-deps chromium
#       - name: Run combined-metric Playwright test
#         env:
#           REMOTE_SERVER_HOST: ${{ secrets.REMOTE_SERVER_HOST }}
#           REMOTE_SERVER_PORT: ${{ secrets.REMOTE_SERVER_PORT }}
#           KAFKA_HOSTS: ${{ secrets.KAFKA_HOSTS }}
#           KAFKA_PORT: ${{ secrets.KAFKA_PORT }}
#           KAFKA_ANALYTICS_TOPIC: cenx-analytics
#           CASSANDRA_HOSTS: ${{ secrets.CASSANDRA_HOSTS }}
#           CASSANDRA_PORT: ${{ secrets.CASSANDRA_PORT }}
#           CASSANDRA_KEYSPACE_PREFIX: cenx
#         run: pytest playwright_combined/tests -m sanity -v
