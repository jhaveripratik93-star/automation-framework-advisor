"""
Playwright (pytest-playwright) port of the Robot Framework test case:

    core-tests/component/analytics/combined.robot
    -> "TCA From Combined Metric"

Original intent (preserved verbatim in assertions):
  Put a TCA (Threshold Crossing Alert) config in Cassandra and load it into
  Levski, then ingest two input samples for SIM_ID3 (A=50.0, B=60.0) whose
  combined metric AverageOfTwo = (50+60)/2 = 55.0 crosses the TCA's 30.0
  major-threshold (direction "over"). This raises the
  AverageOfTwo#nsd-scale-out-policy alarm. The test then waits for:
    1. the active alarm to appear in the Cassandra active_alarms table, and
    2. the TCA message to appear on the Fault Kafka topic
       (data.name == SIM_ID3, data.type == AverageOfTwo#nsd-scale-out-policy).
  Teardown ingests clearing samples (A=10.0, B=20.0 -> 15.0, below 30.0),
  then verifies the active alarm is gone from Cassandra and a Clear message
  reached the Fault Kafka topic.

This is a backend data-pipeline test, so Playwright's APIRequestContext is the
entry point and the Kafka/Cassandra/Levski integrations are helpers, exactly
as the conversion rules require. Robot assertions map to helpers/expect_value.

Shares the same backend helpers and suite-setup pattern as
test_combined_metric.py.
"""

import pytest
from playwright.sync_api import APIRequestContext

from helpers.analytics_keywords import (
    AnalyticsBackend,
    current_time_in_milliseconds,
    make_sample,
    combine_lists,
)
from helpers.expect_value import expect_value

# --- Suite-level variables (from combined.robot *** Variables ***) ---
COMBINED_METRIC = "AverageOfTwo"
CASSANDRA_FIELDS_ACTIVE_ALARMS = ["id", "type", "data", "timestamp"]
COMBINED_METRIC_TOTAL_WAIT = "2 min"
COMBINED_METRIC_INCREMENTAL_STEP = "10 sec"
SIM_ID3 = "vm3"  # Initialize Suite Variables -> vm3


@pytest.fixture(scope="module")
def backend(playwright):
    """
    Equivalent of combined.robot `Suite Setup` / `Suite Teardown` (same as the
    combined-metric suite): connect to Levski + fault, truncate short_term,
    initialize suite variables (incl. TCA configs), insert+load combined config.
    """
    request: APIRequestContext = playwright.request.new_context()
    be = AnalyticsBackend(request)

    try:
        be.connect_to_zookeeper_and_levski()
        be.connect_to_full_fault()
        be.truncate_all_preexisting_rows_from_cassandra_short_term_table()
        be.initialize_suite_variables()
        be.insert_combined_metric_config_on_cassandra()
        be.load_combined_metric_config_in_levski()
    except Exception:
        try:
            be.disconnect()
        finally:
            request.dispose()
        raise

    yield be

    # --- Suite Teardown ---
    be.cleanup()
    be.remove_tca_config()
    be.load_combined_metric_config_in_levski()
    be.disconnect()
    request.dispose()


@pytest.mark.fault
def test_tca_from_combined_metric(backend: AnalyticsBackend):
    """TCA From Combined Metric   [Tags] fault"""
    # ${timestamp}=    Current Time In Milliseconds
    timestamp = current_time_in_milliseconds()

    # Pass If Combined Metrics Disabled
    if backend.combined_metrics_disabled():
        pytest.skip("combined metrics disabled in levski")

    # Setup For TCA Test  (insert TCA config, load in levski, confirm loaded)
    backend.setup_for_tca_test()

    try:
        # Make two aligned samples whose average (55.0) exceeds the 30.0 threshold.
        sample1 = make_sample(SIM_ID3, "A", timestamp, 50.0)
        sample2 = make_sample(SIM_ID3, "B", timestamp, 60.0)
        samples = combine_lists(sample1, sample2)
        short_term_metric_check_list = ["A", "B", "AverageOfTwo"]

        # Ingest Input Samples (Kafka send + poll short_term for A, B, AverageOfTwo)
        ingested_metrics = backend.ingest_input_samples(
            samples, timestamp, short_term_metric_check_list
        )
        for expected_metric in short_term_metric_check_list:
            expect_value(ingested_metrics).to_contain(expected_metric)

        metric_type = f"{COMBINED_METRIC}#nsd-scale-out-policy"
        select_active_alarm3 = backend.select_active_alarm[3]

        # Wait for the active alarm to appear in the Cassandra active_alarms table.
        active_alarm_rows = backend.wait_until_keyword_succeeds(
            COMBINED_METRIC_TOTAL_WAIT,
            COMBINED_METRIC_INCREMENTAL_STEP,
            backend.run_cassandra_query_and_ensure_it_is_not_empty,
            select_active_alarm3,
            CASSANDRA_FIELDS_ACTIVE_ALARMS,
        )
        expect_value(active_alarm_rows).not_to_be_empty()

        # Wait for the TCA message to appear on the Fault Kafka topic.
        backend.wait_until_keyword_succeeds(
            COMBINED_METRIC_TOTAL_WAIT,
            COMBINED_METRIC_INCREMENTAL_STEP,
            backend.verify_tca_message_in_fault_kafka_topic,
            SIM_ID3,
            metric_type,
        )
    finally:
        # [Teardown]  TCA Test Teardown
        _tca_test_teardown(backend)


def _tca_test_teardown(backend: AnalyticsBackend):
    """
    Robot: TCA Test Teardown. Ingest clearing samples (A=10.0, B=20.0 ->
    AverageOfTwo = 15.0, below the 30.0 clear-threshold), then verify the
    active alarm is gone from Cassandra and a Clear message reached Fault Kafka.
    """
    timestamp = current_time_in_milliseconds()
    sample1 = make_sample(SIM_ID3, "A", timestamp, 10.0)
    sample2 = make_sample(SIM_ID3, "B", timestamp, 20.0)
    samples = combine_lists(sample1, sample2)
    short_term_metric_check_list = ["A", "B", "AverageOfTwo"]

    backend.ingest_input_samples(samples, timestamp, short_term_metric_check_list)

    select_active_alarm3 = backend.select_active_alarm[3]
    backend.wait_until_keyword_succeeds(
        COMBINED_METRIC_TOTAL_WAIT,
        COMBINED_METRIC_INCREMENTAL_STEP,
        backend.run_cassandra_query_and_ensure_it_is_empty,
        select_active_alarm3,
        CASSANDRA_FIELDS_ACTIVE_ALARMS,
    )
    backend.wait_until_keyword_succeeds(
        COMBINED_METRIC_TOTAL_WAIT,
        COMBINED_METRIC_INCREMENTAL_STEP,
        backend.verify_tca_clear_message_in_fault_kafka_topic,
    )
