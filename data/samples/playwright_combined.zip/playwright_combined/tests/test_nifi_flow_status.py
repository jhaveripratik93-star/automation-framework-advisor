"""
Playwright (pytest-playwright) port of the Robot Framework test case:

    core-tests/component/nifi.robot
    -> "Can Get Flow Status"

Original:
    Can Get Flow Status
        ${status}=  Nifi.get_flow_status
        Should Contain  ${status}  controllerStatus

Unlike the analytics tests (Kafka/Cassandra/REPL), this one is a plain HTTP
check, so it maps directly onto Playwright's native APIRequestContext — no
custom client needed.

`Nifi.get_flow_status` is implemented in clamps/nifi/nifi.py as
`self.rest.get("flow/status")`, where common/rest.Rest uses plain HTTP
(https_enabled=False) against NIFI_HOSTS[0] (k8s service "nifi"), port 7777
(NIFI_PORT), base path "/nifi-api". So it issues:

    GET http://nifi:7777/nifi-api/flow/status

and returns the parsed JSON, which contains the key "controllerStatus".

The Robot assertion `Should Contain ${status} controllerStatus` checks that
the (stringified) status response contains "controllerStatus". We assert the
HTTP call succeeded and that the response body contains that key.
"""

import os

import pytest
from playwright.sync_api import APIRequestContext

from helpers.backends import BackendUnavailable, resolve_setting


def _nifi_base_url() -> str:
    """
    Build the NiFi REST base URL from the same service config the Robot runner
    used (common_config.py: service "nifi", port 7777, plain HTTP, /nifi-api).
    Each piece is overridable via env (NIFI_HOSTS / NIFI_PORT / NIFI_BASE_PATH).
    A full NIFI_BASE_URL env var, if set, wins outright (e.g. for a port-forward).
    """
    full = os.environ.get("NIFI_BASE_URL")
    if full:
        return full.rstrip("/")

    host = resolve_setting("NIFI_HOSTS", os.environ.get("NIFI_HOSTS"))
    port = resolve_setting("NIFI_PORT", os.environ.get("NIFI_PORT"))
    base_path = resolve_setting("NIFI_BASE_PATH", os.environ.get("NIFI_BASE_PATH")) or "/nifi-api"
    if not host or not port:
        raise BackendUnavailable(
            "NiFi host/port could not be resolved (no env override and no "
            "in-cluster default). Set NIFI_HOSTS/NIFI_PORT or NIFI_BASE_URL."
        )
    # NIFI_HOSTS may be a JSON-ish list string; take the first host.
    host = host.strip().strip('"[]').split(",")[0].strip().strip('"')
    return f"http://{host}:{port}{base_path if base_path.startswith('/') else '/' + base_path}"


@pytest.mark.nifi
def test_can_get_flow_status(playwright):
    """Can Get Flow Status   [Tags] nifi"""
    base_url = _nifi_base_url()
    request: APIRequestContext = playwright.request.new_context(base_url=base_url)
    try:
        # Nifi.get_flow_status -> GET /nifi-api/flow/status
        try:
            response = request.get("/nifi-api/flow/status")
        except Exception as exc:  # noqa: BLE001
            # NiFi not reachable in this environment -> skip (not a false pass),
            # matching the suite's premise that NiFi must be deployed.
            raise BackendUnavailable(f"NiFi not reachable at {base_url}: {exc}") from exc

        # The GET must succeed (the Robot keyword raises on a non-2xx response).
        assert response.ok, (
            f"GET {base_url}/nifi-api/flow/status returned HTTP {response.status}"
        )

        # Robot: Should Contain  ${status}  controllerStatus
        body_text = response.text()
        assert "controllerStatus" in body_text, (
            f"flow/status response did not contain 'controllerStatus': {body_text[:300]}"
        )
    finally:
        request.dispose()
