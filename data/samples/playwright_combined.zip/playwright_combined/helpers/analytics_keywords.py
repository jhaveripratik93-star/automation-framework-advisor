# === HELPER: analytics_keywords ===
"""
Python ports of the Robot Framework keywords used by
"Combined Metric Computed From Aligned Inputs" and its dependency chain
(combined.robot + clamps/analytics/analytics.robot).

These keywords are NOT browser actions, so they live here as helpers (per the
Robot -> Playwright conversion rules). They wrap the three backend integrations
the original suite used through Robot libraries:

  * Levski REPL        <- Robot `Remote` library (clj.analytics/*)   -> LevskiReplClient
  * Kafka producer     <- clamps.infrastructure.kafka_client         -> KafkaProducerClient
  * Cassandra client   <- clamps.databases.cassandra.Cassandra       -> CassandraClient

Pure, side-effect-free keywords (Make Sample, Week For Epoch Time,
Current Time In Milliseconds, Combine Lists) are plain module functions and are
runnable with no backend at all.

Configuration comes from environment variables (same names as the Robot run):
  REMOTE_SERVER_HOST, REMOTE_SERVER_PORT, KAFKA_HOSTS, KAFKA_PORT,
  KAFKA_ANALYTICS_TOPIC, CASSANDRA_HOSTS, CASSANDRA_PORT, CASSANDRA_KEYSPACE_PREFIX
"""

import json
import os
import time
from typing import Any, Callable, List

from playwright.sync_api import APIRequestContext

from helpers.backends import (
    CassandraClient,
    KafkaConsumerClient,
    KafkaProducerClient,
    LevskiReplClient,
    resolve_setting,
)

# Fields returned from the Cassandra short_term table (combined.robot CASSANDRA_FIELDS)
CASSANDRA_FIELDS = ["id", "idfamily", "week", "timestamp", "metric", "vdouble", "vlong", "vtext"]
COMBINED_METRIC = "AverageOfTwo"


# -------------------------------------------------------------------------
# Pure keyword ports (no backend required)
# -------------------------------------------------------------------------
def current_time_in_milliseconds() -> int:
    """Robot: Current Time In Milliseconds -> 1000 * epoch seconds (integer)."""
    return int(1000 * int(time.time()))


def week_for_epoch_time(epoch_time_ms: int) -> int:
    """
    Robot: Week For Epoch Time.
    604800000 ms = one week; 345600000 ms = four days offset because
    1970-01-01 was a Thursday. Integer floor division, matching Robot's `//`.
    """
    return (int(epoch_time_ms) + 345600000) // 604800000


def make_sample(sim_id: str, metric: str, timestamp: int, value: float, frequency: int = 1) -> List[str]:
    """
    Robot: Make Sample. Returns a list of 1..frequency JSON sample strings,
    each with timestamp incremented by the loop index (matching Robot exactly).
    """
    sample_list: List[str] = []
    for index in range(frequency):
        in_timestamp = int(timestamp) + index
        sample = json.dumps(
            {
                "version": 1,
                "id": sim_id,
                "metric-name": metric,
                "timestamp": in_timestamp,
                "value": value,
            }
        )
        sample_list.append(sample)
    return sample_list


def combine_lists(*lists: List[Any]) -> List[Any]:
    """Robot/Collections: Combine Lists -> flatten the given lists into one."""
    combined: List[Any] = []
    for lst in lists:
        combined.extend(lst)
    return combined


# -------------------------------------------------------------------------
# AnalyticsBackend: stateful keywords that touch Kafka/Cassandra/Levski
# -------------------------------------------------------------------------
class AnalyticsBackend:
    """Ports the stateful combined.robot / analytics.robot keywords."""

    def __init__(self, request: APIRequestContext):
        self.request = request

        # Each setting: explicit env var wins, else the in-cluster service
        # default ported from common_config.py (resolve_setting handles both).
        self.keyspace_prefix = resolve_setting(
            "CASSANDRA_KEYSPACE_PREFIX", os.environ.get("CASSANDRA_KEYSPACE_PREFIX")
        )
        self.analytics_topic = resolve_setting(
            "KAFKA_ANALYTICS_TOPIC", os.environ.get("KAFKA_ANALYTICS_TOPIC")
        )

        # Lazily-constructed backend clients (see helpers/backends.py).
        self.levski = LevskiReplClient(
            host=resolve_setting("REMOTE_SERVER_HOST", os.environ.get("REMOTE_SERVER_HOST")),
            port=resolve_setting("REMOTE_SERVER_PORT", os.environ.get("REMOTE_SERVER_PORT")),
            request=request,
            heimdallr_repl_hosts=resolve_setting(
                "HEIMDALLR_REPL_HOSTS", os.environ.get("HEIMDALLR_REPL_HOSTS")
            ),
        )
        self.kafka = KafkaProducerClient(
            hosts=resolve_setting("KAFKA_HOSTS", os.environ.get("KAFKA_HOSTS")),
            port=resolve_setting("KAFKA_PORT", os.environ.get("KAFKA_PORT")),
            topic=self.analytics_topic,
        )
        self.cassandra = CassandraClient(
            hosts=resolve_setting("CASSANDRA_HOSTS", os.environ.get("CASSANDRA_HOSTS")),
            port=resolve_setting("CASSANDRA_PORT", os.environ.get("CASSANDRA_PORT")),
        )
        # Fault Kafka consumer (Robot: FaultKafka / CombinedKafkaFault) — reads
        # the alarms/faults topic to verify raised/cleared TCA messages.
        self.fault_topic = resolve_setting(
            "KAFKA_ALARMS_FAULTS_TOPIC", os.environ.get("KAFKA_ALARMS_FAULTS_TOPIC")
        )
        self.fault_kafka = KafkaConsumerClient(
            hosts=resolve_setting("KAFKA_HOSTS", os.environ.get("KAFKA_HOSTS")),
            port=resolve_setting("KAFKA_PORT", os.environ.get("KAFKA_PORT")),
            topic=self.fault_topic,
        )

        # Populated by initialize_suite_variables()
        self.sim_ids: dict = {}
        self.tca_ids: dict = {}
        self.insert_combined_metric_config: dict = {}
        self.delete_combined_metric_config: dict = {}
        self.insert_tca_config: dict = {}
        self.delete_tca_config: dict = {}
        self.select_active_alarm: dict = {}

    # --- Suite Setup keywords ---
    def connect_to_zookeeper_and_levski(self) -> None:
        self.levski.set_zk_host(
            resolve_setting("ZOOKEEPER_HOSTS", os.environ.get("ZOOKEEPER_HOSTS"))
        )
        self.levski.connect(
            resolve_setting("LEVSKI_REPL_HOSTS", os.environ.get("LEVSKI_REPL_HOSTS"))
        )

    def connect_to_full_fault(self) -> None:
        self.levski.fault_connect()

    def truncate_all_preexisting_rows_from_cassandra_short_term_table(self) -> None:
        self.cassandra.query(
            f"TRUNCATE {self.keyspace_prefix}analytics.short_term;"
        )

    def initialize_suite_variables(self) -> None:
        """
        Robot: Initialize Suite Variables. Builds SIM IDs vm1..vm3 and the
        combined-metric / TCA insert+delete CQL for each.
        """
        for index in range(1, 4):
            sim_id = f"vm{index}"
            tca_id = f"{sim_id}-{COMBINED_METRIC}"
            combined_metric_id = f"{sim_id}-{COMBINED_METRIC}-combined"
            self.sim_ids[index] = sim_id
            self.tca_ids[index] = tca_id

            # TCA config (nsd-scale-out-policy, thresholds 30.0 over) — triggers
            # when the combined metric AverageOfTwo exceeds 30.0.
            self.insert_tca_config[index] = (
                f"INSERT INTO {self.keyspace_prefix}.entity(id, type, basetype, value) "
                f"VALUES('{tca_id}', 'TCAMeasurement', 'SIMMeasurement', "
                f'\'{{"_id":"{tca_id}", "_type":"TCAMeasurement", '
                f'"tca":[{{"type":"nsd-scale-out-policy", "hold-on-period":"1", '
                f'"hold-off-period":"1", "major-threshold":"30.0", "clear-threshold":"30.0", '
                f'"direction":"over", "alarm-augmentation":{{"vnfoType":"HP", '
                f'"vnfoId":"{sim_id}", "maximumInstancesScaleOut":"5", '
                f'"scaleOutIncrement":"50", "warmupPeriod":"1800", "action":"scaleOut"}}}}], '
                f'"_base":"SIMMeasurement", "_erl":"TCAMeasurement:{tca_id}"}}\')'
            )
            # Active-alarm lookup for this SIM's combined-metric scale-out policy.
            self.select_active_alarm[index] = (
                f"SELECT * from {self.keyspace_prefix}analytics_high_rep.active_alarms "
                f"where id='{sim_id}' and type='{COMBINED_METRIC}#nsd-scale-out-policy';"
            )

            self.insert_combined_metric_config[index] = (
                f"INSERT INTO {self.keyspace_prefix}.entity(id, type, basetype, value) "
                f"VALUES('{combined_metric_id}', 'CombinedMeasurement', 'SIMMeasurement', "
                f'\'{{"_type":"CombinedMeasurement", "_base":"SIMMeasurement", '
                f'"_erl":"CombinedMeasurement:{combined_metric_id}", "name":"{COMBINED_METRIC}", '
                f'"combinedAnalyticsId":"{sim_id}", '
                f'"inputMetrics":[{{"metricName":"A","collectionPeriod":"60"}}, '
                f'{{"metricName":"B","collectionPeriod":"60"}}], "_id":"{combined_metric_id}", '
                f'"formula":"function (A, B) {{ return (A + B) / 2; }}"}}\')'
            )
            self.delete_combined_metric_config[index] = (
                f"DELETE FROM {self.keyspace_prefix}.entity where id='{combined_metric_id}';"
            )
            self.delete_tca_config[index] = (
                f"DELETE FROM {self.keyspace_prefix}.entity where id='{tca_id}';"
            )

    def insert_combined_metric_config_on_cassandra(self) -> None:
        for index in (1, 2, 3):
            self.cassandra.query(self.insert_combined_metric_config[index])

    def load_combined_metric_config_in_levski(self) -> None:
        self.levski.load_combined_metric_configs()

    # --- TCA setup keywords (for "TCA From Combined Metric") ---
    def setup_for_tca_test(self) -> None:
        """Robot: Setup For TCA Test -> insert TCA config, load in levski, confirm loaded."""
        self.insert_tca_config_on_cassandra()
        self.load_tca_config_in_levski()
        self.wait_until_keyword_succeeds("1 min", "10 sec", self.check_levski_has_tca_config)

    def insert_tca_config_on_cassandra(self) -> None:
        for index in (1, 2, 3):
            self.cassandra.query(self.insert_tca_config[index])

    def load_tca_config_in_levski(self) -> None:
        self.levski.load_tca_configs()

    def check_levski_has_tca_config(self) -> None:
        """Robot: Check Levski Has TCA Config -> all three TCA configs loaded."""
        for index in (1, 2, 3):
            if not self.levski.tca_config_exists(self.tca_ids[index]):
                raise AssertionError(f"TCA config {self.tca_ids[index]!r} not loaded in levski")

    # --- Active-alarm query helpers ---
    def run_cassandra_query_and_ensure_it_is_not_empty(
        self, select_active_alarm: str, cassandra_fields: List[str]
    ) -> List[dict]:
        """Robot: Run Cassandra Query and Ensure It Is Not Empty."""
        response = self.cassandra.query_and_get_fields(select_active_alarm, cassandra_fields)
        if not response:
            raise AssertionError(f"query returned empty, expected rows: {select_active_alarm}")
        return response

    def run_cassandra_query_and_ensure_it_is_empty(
        self, query: str, cassandra_fields: List[str]
    ) -> List[dict]:
        """Robot: Run Cassandra Query and Ensure It Is Empty."""
        response = self.cassandra.query_and_get_fields(query, cassandra_fields)
        if response:
            raise AssertionError(f"query returned rows, expected empty: {response!r}")
        return response

    # --- Fault Kafka verification keywords ---
    def verify_tca_message_in_fault_kafka_topic(self, sim_id: str, metric_type: str) -> None:
        """
        Robot: Verify TCA Message In Fault Kafka Topic. Scan the 10 most recent
        fault-kafka messages for one whose data.name == sim_id and
        data.type == metric_type. Raises if none match (so the caller's
        Wait Until Keyword Succeeds retries).
        """
        messages = self.fault_kafka.get_n_recent_messages(10)
        if not messages:
            raise AssertionError("no messages on fault kafka topic")
        for raw in reversed(messages):
            try:
                data = json.loads(raw).get("data", {})
            except (ValueError, TypeError):
                continue
            if str(data.get("name")) == str(sim_id) and str(data.get("type")) == str(metric_type):
                return
        raise AssertionError(
            f"no TCA message found with name={sim_id} type={metric_type} in recent fault kafka messages"
        )

    def verify_tca_clear_message_in_fault_kafka_topic(self) -> None:
        """
        Robot: Verify TCA Clear Message In Fault Kafka Topic. Scan the 10 most
        recent fault-kafka messages for the Clear-alarm details string.
        """
        expected = (
            "Analytics AverageOfTwo#nsd-scale-out-policy below 30.0 "
            "for 1 consecutive samples."
        )
        messages = self.fault_kafka.get_n_recent_messages(10)
        if not messages:
            raise AssertionError("no messages on fault kafka topic")
        for raw in reversed(messages):
            try:
                details = json.loads(raw).get("data", {}).get("details")
            except (ValueError, TypeError):
                continue
            if details == expected:
                return
        raise AssertionError(
            f"no TCA clear message found with details={expected!r} in recent fault kafka messages"
        )

    def remove_tca_config(self) -> None:
        """Delete the TCA configs from cassandra (used by suite teardown/cleanup)."""
        for index in (1, 2, 3):
            self.cassandra.query(self.delete_tca_config[index])

    # --- Test-body keywords ---
    def combined_metrics_disabled(self) -> bool:
        """Robot: Pass If Combined Metrics Disabled -> clj.analytics/combined metrics disabled?"""
        return bool(self.levski.combined_metrics_disabled())

    def ingest_input_samples(
        self,
        samples_list: List[str],
        start_range: int,
        short_term_metric_check_list: List[str],
        short_term_metric_field: str = "metric",
    ) -> List[str]:
        """
        Robot: Ingest Input Samples -> send to Kafka then poll short_term until it
        contains every metric in the check list. Returns the found metric names.
        """
        self.kafka.send_messages(samples_list)

        def _check() -> List[str]:
            return self.check_short_term_table_values(
                start_range, short_term_metric_check_list, short_term_metric_field
            )

        # Robot: Wait Until Keyword Succeeds  2 min 30 sec  10 sec
        return self.wait_until_keyword_succeeds("2 min 30 sec", "10 sec", _check)

    def check_short_term_table_values(
        self,
        start_range: int,
        short_term_metric_check_list: List[str],
        short_term_metric_field: str = "metric",
    ) -> List[str]:
        """
        Robot: Check Short Term Table Values. Queries short_term for rows at/after
        start_range and asserts every expected metric is present
        (`list should contain deep sub list`). Returns the metric names found.
        """
        query = (
            f"SELECT * FROM {self.keyspace_prefix}analytics.short_term "
            f"WHERE timestamp >= {start_range} ALLOW FILTERING;"
        )
        responses = self.cassandra.query_and_get_fields(query, CASSANDRA_FIELDS)
        metric_responses = [row["metric"] for row in responses]
        for expected in short_term_metric_check_list:
            if expected not in metric_responses:
                raise AssertionError(
                    f"short_term missing metric {expected!r}; found {metric_responses!r}"
                )
        return metric_responses

    def check_short_term_contains_combined_metric(
        self,
        sim_id: str,
        timestamp: int,
        week: int,
        combined_metric: str = COMBINED_METRIC,
    ) -> List[dict]:
        """
        Robot: Check ShortTerm Contains Combined Metric. Returns the matching
        short_term rows; raises if empty (so Wait Until Keyword Succeeds retries).
        """
        query = (
            f"SELECT * FROM {self.keyspace_prefix}analytics.short_term "
            f"where id='{sim_id}' and idfamily='vim' and week={week} "
            f"and timestamp={timestamp} and metric='{combined_metric}';"
        )
        response = self.cassandra.query_and_get_fields(query, CASSANDRA_FIELDS)
        if not response:
            raise AssertionError(
                f"short_term has no {combined_metric!r} row for id={sim_id} "
                f"week={week} timestamp={timestamp}"
            )
        return response

    # --- Teardown keywords ---
    def teardown_for_tests(self, sim_id: str, timestamp1: int, timestamp2: int) -> None:
        """
        Robot: Teardown For Tests. Delete short_term entries for both weeks, wait
        until the short_term query is empty, then clear misaligned-timestamp state.
        """
        week1 = week_for_epoch_time(timestamp1)
        week2 = week_for_epoch_time(timestamp2)
        self.delete_short_term_table_entries(sim_id, "vim", week1)
        self.delete_short_term_table_entries(sim_id, "vim", week2)

        query = (
            f"SELECT * FROM {self.keyspace_prefix}analytics.short_term "
            f"where id='{sim_id}' and idfamily='vim' allow filtering;"
        )

        def _ensure_empty() -> None:
            rows = self.cassandra.query_and_get_fields(query, CASSANDRA_FIELDS)
            if rows:
                raise AssertionError(f"short_term still has rows for {sim_id}: {rows!r}")

        self.wait_until_keyword_succeeds("2 min", "10 sec", _ensure_empty)
        self.levski.clear_misaligned_timestamps_log_state()

    def delete_short_term_table_entries(self, sim_id: str, idfamily: str, week: int) -> None:
        self.cassandra.query(
            f"DELETE FROM {self.keyspace_prefix}analytics.short_term "
            f"where id='{sim_id}' and idfamily='{idfamily}' and week={week};"
        )

    def cleanup(self) -> None:
        """Robot: Cleanup -> remove combined-metric and TCA configs from cassandra."""
        for index in (1, 2, 3):
            self.cassandra.query(self.delete_combined_metric_config[index])
            self.cassandra.query(self.delete_tca_config[index])

    def disconnect(self) -> None:
        self.levski.disconnect()
        self.levski.fault_disconnect()

    # --- Control-flow keyword ---
    @staticmethod
    def wait_until_keyword_succeeds(
        timeout: str, retry_interval: str, keyword: Callable, *args
    ) -> Any:
        """
        Robot: Wait Until Keyword Succeeds. Retries `keyword(*args)` until it does
        not raise, or until `timeout` elapses, sleeping `retry_interval` between
        attempts. Accepts Robot time strings ("2 min", "10 sec", "2 min 30 sec").
        """
        deadline = time.monotonic() + _parse_robot_time(timeout)
        interval = _parse_robot_time(retry_interval)
        last_error: Exception | None = None
        while True:
            try:
                return keyword(*args)
            except Exception as exc:  # noqa: BLE001 - mirrors Robot retry semantics
                last_error = exc
                if time.monotonic() >= deadline:
                    raise
                time.sleep(interval)


def _parse_robot_time(value: str) -> float:
    """Parse a Robot time string like '2 min', '10 sec', '2 min 30 sec' into seconds."""
    if isinstance(value, (int, float)):
        return float(value)
    units = {
        "ms": 0.001, "millisecond": 0.001, "milliseconds": 0.001,
        "s": 1, "sec": 1, "secs": 1, "second": 1, "seconds": 1,
        "min": 60, "mins": 60, "minute": 60, "minutes": 60,
        "h": 3600, "hour": 3600, "hours": 3600,
    }
    tokens = value.replace("\t", " ").split()
    total = 0.0
    i = 0
    while i < len(tokens):
        number = float(tokens[i])
        unit = tokens[i + 1].lower() if i + 1 < len(tokens) else "s"
        total += number * units.get(unit, 1)
        i += 2
    return total
