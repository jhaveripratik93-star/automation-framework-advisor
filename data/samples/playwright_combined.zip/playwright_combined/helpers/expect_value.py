# === HELPER: expect_value ===
"""
A tiny web-first-style assertion shim for NON-DOM values.

Playwright's native `expect()` only operates on Page/Locator/APIResponse
objects. The combined-metric test asserts on backend values (Cassandra rows,
numeric metric values), so we provide an `expect(value)`-style wrapper that
mirrors the Robot Framework assertions it replaces:

    Robot `Should Not Be Empty`        -> expect_value(x).not_to_be_empty()
    Robot `list should contain ...`    -> expect_value(x).to_contain(item)
    Robot `Should Be Equal As Numbers` -> expect_value(x).to_equal_as_number(n)
    Robot `Should Be Equal`            -> expect_value(x).to_equal(y)

Each assertion raises AssertionError (pytest-friendly) with a clear message.
"""

from typing import Any


class _ValueAssertions:
    def __init__(self, actual: Any):
        self._actual = actual

    def not_to_be_empty(self) -> None:
        assert self._actual, f"Expected value to NOT be empty, got: {self._actual!r}"

    def to_be_empty(self) -> None:
        assert not self._actual, f"Expected value to be empty, got: {self._actual!r}"

    def to_contain(self, item: Any) -> None:
        assert item in self._actual, f"Expected {self._actual!r} to contain {item!r}"

    def to_equal(self, expected: Any) -> None:
        assert self._actual == expected, f"Expected {self._actual!r} == {expected!r}"

    def to_equal_as_number(self, expected: float) -> None:
        assert float(self._actual) == float(expected), (
            f"Expected number {self._actual!r} == {expected!r}"
        )


def expect_value(actual: Any) -> _ValueAssertions:
    return _ValueAssertions(actual)
