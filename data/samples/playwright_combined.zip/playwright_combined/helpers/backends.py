# === HELPER: backends ===
"""
Thin backend clients that replace the Robot Framework libraries the original
combined.robot suite used:

  LevskiReplClient  <- Robot `Remote` library  (keyword server / clj.analytics/*)
  KafkaProducerClient <- clamps.infrastructure.kafka_client.AnalyticsKafkaClient
  CassandraClient   <- clamps.databases.cassandra.Cassandra

Each client talks to a real backend when its driver library is installed AND
connection details are supplied via environment variables. When a driver or
connection is missing, the client raises BackendUnavailable with a clear
message so the test is skipped rather than silently passing — preserving the
original test's requirement that Levski/Kafka/Cassandra be deployed.
"""

import os
from typing import Any, List, Optional

import pytest


class BackendUnavailable(Exception):
    """Raised when a required backend driver or connection is not available."""


# In-cluster service defaults, ported verbatim from the original Robot runner's
# autotest/configs/common_config.py. There, these values were NOT environment
# variables -- they were computed at runtime via resolve_hostname_to_ip(<svc>).
# Inside the robot-poc namespace the Kubernetes DNS for those services resolves
# directly, so we default to the service names and let the cluster resolve them.
# An explicit environment variable (if set) always overrides the default.
CLUSTER_DEFAULTS = {
    "REMOTE_SERVER_HOST": "kw-server",
    "REMOTE_SERVER_PORT": "8270",
    "ZOOKEEPER_HOSTS": "zookeeper",
    "ZOOKEEPER_PORT": "2181",
    "LEVSKI_REPL_HOSTS": "eric-cenx-analytics",
    "HEIMDALLR_REPL_HOSTS": "eric-cenx-fault-repl",
    "KAFKA_HOSTS": "kafka",
    "KAFKA_PORT": "9092",
    "KAFKA_ANALYTICS_TOPIC": "cenx-analytics",
    "KAFKA_ALARMS_FAULTS_TOPIC": "cenx.alarms.faults",
    "CASSANDRA_HOSTS": "cassandra",
    "CASSANDRA_PORT": "9042",
    "CASSANDRA_KEYSPACE_PREFIX": "cenx",
    # NiFi (clamps/nifi/nifi.py + common_config.py): plain HTTP, base /nifi-api.
    "NIFI_HOSTS": "nifi",
    "NIFI_PORT": "7777",
    "NIFI_BASE_PATH": "/nifi-api",
}


def resolve_setting(name: str, override: Optional[str]) -> Optional[str]:
    """
    Resolve a connection setting: an explicit value/env override wins, otherwise
    fall back to the in-cluster service default from CLUSTER_DEFAULTS (mirroring
    common_config.py). Returns None only if there is neither an override nor a
    known default.
    """
    if override:
        return override
    return CLUSTER_DEFAULTS.get(name)


def _require(value: Optional[str], name: str) -> str:
    if not value:
        raise BackendUnavailable(
            f"{name} could not be resolved (no env override and no in-cluster "
            f"default). Set it in the environment to run against a live deployment."
        )
    return value


# -------------------------------------------------------------------------
# Levski REPL (was Robot `Remote` library, aliased `clj`)
# -------------------------------------------------------------------------
class LevskiReplClient:
    """
    Wraps the Levski keyword/REPL server. The Robot suite called it through the
    `Remote` library (e.g. `clj.analytics/combined metrics disabled?`). Here we
    talk to the same keyword server over XML-RPC when reachable.
    """

    def __init__(
        self,
        host: Optional[str],
        port: Optional[str],
        request: Any = None,
        heimdallr_repl_hosts: Optional[str] = None,
    ):
        self.host = host
        self.port = port
        self.request = request
        # Comma- or JSON-list string of Heimdallr REPL hosts for fault_connect.
        self.heimdallr_repl_hosts = heimdallr_repl_hosts
        self._proxy = None

    def _server(self):
        if self._proxy is None:
            host = _require(self.host, "REMOTE_SERVER_HOST")
            port = _require(self.port, "REMOTE_SERVER_PORT")
            try:
                from xmlrpc.client import ServerProxy
            except Exception as exc:  # pragma: no cover
                raise BackendUnavailable(f"xmlrpc unavailable: {exc}") from exc
            self._proxy = ServerProxy(f"http://{host}:{port}")
        return self._proxy

    def _run(self, keyword: str, *args):
        try:
            result = self._server().run_keyword(keyword, list(args))
        except BackendUnavailable:
            raise
        except Exception as exc:  # pragma: no cover - network/remote failure
            raise BackendUnavailable(f"Levski keyword {keyword!r} failed: {exc}") from exc
        if isinstance(result, dict):
            if result.get("status") == "PASS":
                return result.get("return")
            raise AssertionError(result.get("error") or f"{keyword} failed")
        return result

    # NOTE: the Levski keyword server registers keyword names with UNDERSCORES
    # (confirmed via get_keyword_names on the live server), e.g.
    # "analytics/set_zk_host". The Robot `Remote` library normalized spaced
    # Robot keywords to this form automatically; here we send the exact names.
    def set_zk_host(self, host: Optional[str]) -> None:
        self._run("analytics/set_zk_host", host)

    def connect(self, repl_host: Optional[str]) -> None:
        # The Levski keyword server holds REPL connection state globally and
        # persistently. If a previous run failed before its teardown ran, the
        # analytics REPL stays connected and analytics/connect then errors with
        # "Already connected.". Make connect idempotent: drop any stale session
        # first (mirrors the Robot "disconnect then connect" recovery keywords).
        try:
            self._run("analytics/disconnect")
        except (BackendUnavailable, AssertionError):
            pass
        self._run("analytics/connect", repl_host)

    def disconnect(self) -> None:
        try:
            self._run("analytics/disconnect")
        except BackendUnavailable:
            pass

    def fault_connect(self) -> None:
        """
        Port of Robot `Connect To Full Fault` (clamps/fault/fault.robot):
        connect to each Heimdallr REPL host and stay on the FIRST one that
        reports it is in "full" mode; otherwise disconnect and try the next.
        `fault/connect` requires the host argument (the server rejected a
        zero-arg call with an ArityException).
        """
        hosts = _parse_host_list(self.heimdallr_repl_hosts)
        _require(hosts[0] if hosts else None, "HEIMDALLR_REPL_HOSTS")

        # Drop any stale fault REPL session left by a prior failed run before
        # reconnecting, so fault/connect doesn't hit "Already connected.".
        try:
            self._run("fault/disconnect")
        except (BackendUnavailable, AssertionError):
            pass

        connected = False
        for host in hosts:
            self._run("fault/connect", host)
            connected = True
            is_full = self._run("fault/is_full_heimdallr?")
            # server returns the string "true"/"false"
            if str(is_full).lower() == "true":
                return
            try:
                self._run("fault/disconnect")
            except BackendUnavailable:
                pass
            connected = False
        if not connected:
            raise AssertionError(
                f"Unable to find full heimdallr in hosts: {hosts}"
            )

    def fault_disconnect(self) -> None:
        try:
            self._run("fault/disconnect")
        except BackendUnavailable:
            pass

    def combined_metrics_disabled(self) -> bool:
        return bool(self._run("analytics/combined_metrics_disabled?"))

    def load_combined_metric_configs(self) -> None:
        self._run("analytics/load_combined_metric_configs")

    def clear_misaligned_timestamps_log_state(self) -> None:
        self._run("analytics/clear_misaligned_timestamps_log_state")

    def load_tca_configs(self) -> None:
        # Robot: clj.analytics/load tca configs -> analytics/load_tca_configs
        self._run("analytics/load_tca_configs")

    def tca_config_exists(self, tca_id: str) -> bool:
        # Robot: clj.analytics/tca config exists? -> analytics/tca_config_exists?
        return bool(self._run("analytics/tca_config_exists?", tca_id))


# -------------------------------------------------------------------------
# Kafka producer (was AnalyticsKafkaClient / KafkaClient)
# -------------------------------------------------------------------------
class KafkaProducerClient:
    """Sends analytics sample JSON strings to the analytics Kafka topic."""

    def __init__(self, hosts: Optional[str], port: Optional[str], topic: str):
        self.hosts = hosts
        self.port = port
        self.topic = topic
        self._producer = None

    def _get_producer(self):
        if self._producer is None:
            hosts = _require(self.hosts, "KAFKA_HOSTS")
            port = _require(self.port, "KAFKA_PORT")
            try:
                from kafka import KafkaProducer  # type: ignore
            except Exception as exc:
                raise BackendUnavailable(
                    "kafka-python is not installed; `pip install kafka-python` to "
                    "run against a live Kafka broker."
                ) from exc
            # KAFKA_HOSTS may be a JSON-ish list like ["h1","h2"] or a plain host.
            first_host = _first_host(hosts)
            self._producer = KafkaProducer(
                bootstrap_servers=f"{first_host}:{port}",
                value_serializer=lambda v: v.encode("utf-8") if isinstance(v, str) else v,
            )
        return self._producer

    def send_messages(self, messages: List[str], key: Optional[str] = None) -> None:
        producer = self._get_producer()
        key_bytes = key.encode("utf-8") if key else None
        for message in messages:
            producer.send(self.topic, value=message, key=key_bytes)
        producer.flush()


# -------------------------------------------------------------------------
# Kafka consumer (was FaultKafkaClient.get_n_recent_messages)
# -------------------------------------------------------------------------
class KafkaConsumerClient:
    """
    Reads the most recent messages from a Kafka topic. Ports the behavior of
    the original FaultKafkaClient.get_n_recent_messages(n): seek to the last n
    messages across all partitions and return their JSON string values.
    """

    def __init__(self, hosts: Optional[str], port: Optional[str], topic: str):
        self.hosts = hosts
        self.port = port
        self.topic = topic

    def get_n_recent_messages(self, num: int) -> List[str]:
        hosts = _require(self.hosts, "KAFKA_HOSTS")
        port = _require(self.port, "KAFKA_PORT")
        try:
            from kafka import KafkaConsumer, TopicPartition  # type: ignore
        except Exception as exc:
            raise BackendUnavailable(
                "kafka-python is not installed; `pip install kafka-python` to "
                "run against a live Kafka broker."
            ) from exc

        first_host = _first_host(hosts)
        consumer = KafkaConsumer(
            bootstrap_servers=f"{first_host}:{port}",
            enable_auto_commit=False,
            consumer_timeout_ms=10000,
            value_deserializer=lambda v: v.decode("utf-8") if v is not None else None,
        )
        try:
            partitions = consumer.partitions_for_topic(self.topic) or set()
            tps = [TopicPartition(self.topic, p) for p in partitions]
            if not tps:
                return []
            consumer.assign(tps)

            end_offsets = consumer.end_offsets(tps)
            # Divide the requested count across partitions, like the original.
            per_partition = max(1, num // max(1, len(tps)))
            for tp in tps:
                end = end_offsets.get(tp, 0)
                start = max(0, end - per_partition)
                consumer.seek(tp, start)

            messages: List[str] = []
            try:
                for record in consumer:
                    if record.value is not None:
                        messages.append(record.value)
                    if num and len(messages) >= num:
                        break
            except Exception as exc:  # noqa: BLE001
                # The Fault/alarms topic publishes snappy-compressed messages;
                # if the snappy codec isn't installed, kafka-python raises
                # UnsupportedCodecError here. Surface it as a skip-worthy
                # BackendUnavailable with the concrete remediation rather than
                # a cryptic consumer traceback.
                if type(exc).__name__ == "UnsupportedCodecError" or "codec" in str(exc).lower():
                    raise BackendUnavailable(
                        f"Kafka messages use a compression codec that is not "
                        f"installed ({exc}). Install the codec in the runtime, e.g. "
                        f"`pip install cramjam` (pure wheel) or `pip install python-snappy` "
                        f"(needs native libsnappy)."
                    ) from exc
                raise
            return messages
        finally:
            consumer.close()


# -------------------------------------------------------------------------
# Cassandra client (was clamps.databases.cassandra.Cassandra)
# -------------------------------------------------------------------------
class CassandraClient:
    """Executes CQL and maps rows to dicts keyed by the requested field list."""

    # Auth details ported verbatim from the original Robot Cassandra library
    # (clamps/databases/cassandra/cassandra.py): PlainTextAuthProvider with
    # username 'cenxcassandra' and the password read from a mounted secret.
    DEFAULT_CASSANDRA_USER = "cenxcassandra"
    DEFAULT_PASSWORD_FILE = "/opt/cenx/secrets/cassandraPasswords/cenxcassandra/password"

    def __init__(self, hosts: Optional[str], port: Optional[str]):
        self.hosts = hosts
        self.port = port
        self._session = None

    def _read_password(self) -> Optional[str]:
        """
        Resolve the Cassandra password: CASSANDRA_PASSWORD env wins, else read
        the mounted secret file (path overridable via CASSANDRA_PASSWORD_FILE),
        matching the original library's utils.read_file(...) behavior.
        """
        env_pw = os.environ.get("CASSANDRA_PASSWORD")
        if env_pw:
            return env_pw
        path = os.environ.get("CASSANDRA_PASSWORD_FILE", self.DEFAULT_PASSWORD_FILE)
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return fh.read().strip()
        except OSError:
            return None

    def _get_session(self):
        if self._session is None:
            hosts = _require(self.hosts, "CASSANDRA_HOSTS")
            port = _require(self.port, "CASSANDRA_PORT")
            try:
                from cassandra.cluster import Cluster  # type: ignore
                from cassandra.auth import PlainTextAuthProvider  # type: ignore
                from cassandra.policies import RoundRobinPolicy  # type: ignore
            except Exception as exc:
                raise BackendUnavailable(
                    "cassandra-driver is not installed; `pip install cassandra-driver` "
                    "to run against a live Cassandra cluster."
                ) from exc

            username = os.environ.get("CASSANDRA_USER", self.DEFAULT_CASSANDRA_USER)
            password = self._read_password()
            if password is None:
                raise BackendUnavailable(
                    f"Cassandra requires authentication but no password was found. "
                    f"Expected the mounted secret at "
                    f"{os.environ.get('CASSANDRA_PASSWORD_FILE', self.DEFAULT_PASSWORD_FILE)} "
                    f"or the CASSANDRA_PASSWORD env var."
                )
            auth_provider = PlainTextAuthProvider(username=username, password=password)

            cluster = Cluster(
                [_first_host(hosts)],
                port=int(port),
                auth_provider=auth_provider,
                load_balancing_policy=RoundRobinPolicy(),
            )
            self._session = cluster.connect()
        return self._session

    def query(self, cql: str) -> Any:
        return self._get_session().execute(cql)

    def query_and_get_fields(self, cql: str, fields: List[str]) -> List[dict]:
        rows = self._get_session().execute(cql)
        result: List[dict] = []
        for row in rows:
            as_dict = row._asdict() if hasattr(row, "_asdict") else dict(row)
            result.append({field: as_dict.get(field) for field in fields})
        return result


def _first_host(hosts: str) -> str:
    """
    KAFKA_HOSTS / CASSANDRA_HOSTS may be set as a JSON list string
    (e.g. '["172.17.0.1"]') or a plain host. Return the first host.
    """
    value = hosts.strip()
    if value.startswith("["):
        import json

        try:
            parsed = json.loads(value)
            if parsed:
                return str(parsed[0])
        except Exception:
            pass
    return value.split(",")[0].strip().strip('"[]')


def _parse_host_list(hosts: Optional[str]) -> list:
    """
    Parse a hosts setting into an ordered list. Accepts a JSON list string
    ('["h1","h2"]'), a comma-separated string ('h1,h2'), or a single host.
    Returns [] when nothing is configured.
    """
    if not hosts:
        return []
    value = hosts.strip()
    if value.startswith("["):
        import json

        try:
            parsed = json.loads(value)
            return [str(h) for h in parsed if str(h).strip()]
        except Exception:
            pass
    return [h.strip().strip('"[]') for h in value.split(",") if h.strip()]
