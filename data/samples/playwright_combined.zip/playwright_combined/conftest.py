"""
pytest configuration for the Playwright combined-metric test.

Makes the package importable (so `from helpers... import ...` works) and turns
a missing/unreachable backend into a SKIP, matching the Robot suite's premise
that Levski, Kafka and Cassandra must be deployed for this test to run.
"""

import os
import sys

import pytest

# Ensure the project root (this directory) is importable for `helpers.*`.
sys.path.insert(0, os.path.dirname(__file__))

from helpers.backends import BackendUnavailable  # noqa: E402


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """
    Convert a BackendUnavailable raised during setup or the test body into a
    clean SKIP, so a missing live backend is reported the same way Robot's
    `Pass Execution If` short-circuits rather than as a failure or xfail.
    """
    outcome = yield
    report = outcome.get_result()
    if call.excinfo is not None and call.excinfo.errisinstance(BackendUnavailable):
        report.outcome = "skipped"
        # pytest's terminal reporter expects a (path, lineno, reason) tuple for skips.
        report.longrepr = (
            str(item.fspath),
            item.location[1] or 0,
            f"Skipped: backend unavailable: {call.excinfo.value}",
        )
        if hasattr(report, "wasxfail"):
            del report.wasxfail
