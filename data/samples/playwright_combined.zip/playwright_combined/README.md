# Combined Metric — Playwright (pytest) port

Playwright/pytest port of the Robot Framework test case
**"Combined Metric Computed From Aligned Inputs"** from
`autotest/core-tests/component/analytics/combined.robot`, converted with the
Automation Framework Advisor MCP server (`convert_test_code`,
Robot Framework → Playwright).

## What the test does

This is a **backend data-pipeline** test, not a UI test:

1. Ingest two *aligned* samples for entity `vm1` (SIM_ID1) — metric `A = 10.0`
   and metric `B = 20.0` at the **same timestamp** — onto the analytics Kafka
   topic.
2. Levski computes the combined metric `AverageOfTwo = (A + B) / 2 = 15.0` and
   writes it to the Cassandra `analytics.short_term` table.
3. The test verifies `short_term` contains `A`, `B` and `AverageOfTwo` for the
   `(id, week, timestamp)`, and that the combined value is `15.0`.
4. Teardown deletes the ingested `short_term` rows and clears the
   misaligned-timestamp log state.

Because Playwright's native `expect()` targets the DOM/HTTP, the non-browser
integrations are implemented as helpers (per the conversion rules):

| Original Robot library | Replacement helper |
|---|---|
| `Remote` (`clj.analytics/*`) Levski REPL | `helpers/backends.py: LevskiReplClient` |
| `clamps.infrastructure.kafka_client` | `helpers/backends.py: KafkaProducerClient` |
| `clamps.databases.cassandra.Cassandra` | `helpers/backends.py: CassandraClient` |

Robot assertions map to `helpers/expect_value.py` (`not_to_be_empty`,
`to_contain`, `to_equal_as_number`), and `Pass Execution If` maps to
`pytest.skip`.

## Layout

```
playwright_combined/
├── conftest.py                 # import path + "backend unavailable => skip"
├── pytest.ini                  # markers (sanity) + testpaths
├── requirements.txt
├── helpers/
│   ├── analytics_keywords.py   # Robot keyword ports + AnalyticsBackend
│   ├── backends.py             # Kafka / Cassandra / Levski REPL clients
│   └── expect_value.py         # web-first-style assertions for non-DOM values
└── tests/
    └── test_combined_metric.py # the ported test case
```

## Install

```powershell
pip install -r playwright_combined/requirements.txt
python -m playwright install chromium
```

## Configure (live run)

The connection settings default to the same in-cluster Kubernetes service
names the original Robot runner used (`autotest/configs/common_config.py`,
which resolved them with `resolve_hostname_to_ip(<service>)` rather than env
vars). So **inside the `robot-poc` namespace no configuration is needed** —
the services resolve by DNS:

| Setting | In-cluster default |
|---|---|
| `REMOTE_SERVER_HOST` / `REMOTE_SERVER_PORT` | `kw-server` / `8270` |
| `ZOOKEEPER_HOSTS` / `ZOOKEEPER_PORT` | `zookeeper` / `2181` |
| `LEVSKI_REPL_HOSTS` | `eric-cenx-analytics` |
| `KAFKA_HOSTS` / `KAFKA_PORT` | `kafka` / `9092` |
| `KAFKA_ANALYTICS_TOPIC` | `cenx-analytics` |
| `CASSANDRA_HOSTS` / `CASSANDRA_PORT` | `cassandra` / `9042` |
| `CASSANDRA_KEYSPACE_PREFIX` | `cenx` |

Any of these can be overridden with an environment variable (useful for a
laptop run against port-forwarded services), e.g.:

```powershell
$env:KAFKA_HOSTS     = '["172.17.0.1"]'
$env:CASSANDRA_HOSTS = '["172.17.0.1"]'
```

## Run

```powershell
pytest playwright_combined/tests -m sanity -v
```

If the backend drivers or connection env vars are missing, the test **skips**
with a clear reason (matching the original requirement that Levski/Kafka/
Cassandra be deployed) rather than producing a false pass.
