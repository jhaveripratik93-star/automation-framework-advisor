*** Settings ***
Library    Collections

*** Keywords ***
Get Auth Headers
    [Arguments]    ${token}
    ${headers}=    Create Dictionary
    ...    Content-Type=application/json
    ...    Authorization=Bearer ${token}
    RETURN    ${headers}

Assert Status
    [Arguments]    ${response}    ${expected_status}
    Status Should Be    ${expected_status}    ${response}
