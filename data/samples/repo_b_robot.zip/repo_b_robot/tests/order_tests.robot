*** Settings ***
Library     RequestsLibrary
Library     Collections
Resource    ../resources/common.robot
Resource    ../clamps/keywords.robot

Suite Setup     Create Session    api    ${BASE_URL}

*** Variables ***
${BASE_URL}    https://api.example.com
${TOKEN}       test-token-123

*** Test Cases ***
Create New Order
    [Documentation]    TC3 - Verify order creation returns 201 with order details
    ${headers}=    Get Auth Headers    ${TOKEN}
    ${body}=    Create Dictionary    product_id=${42}    quantity=${2}
    ${response}=    POST On Session    api    /api/orders    json=${body}    headers=${headers}
    Status Should Be    201    ${response}
    ${json}=    Set Variable    ${response.json()}
    Dictionary Should Contain Key    ${json}    order_id
    Should Be Equal As Integers    ${json}[quantity]    2

Delete Order
    [Documentation]    TC5 - Verify order deletion returns 204
    ${headers}=    Get Auth Headers    ${TOKEN}
    ${response}=    DELETE On Session    api    /api/orders/42    headers=${headers}
    Status Should Be    204    ${response}
    Should Be Equal As Strings    ${response.text}    ${EMPTY}
