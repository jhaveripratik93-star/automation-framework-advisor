*** Settings ***
Library     RequestsLibrary
Library     Collections
Resource    ../resources/common.robot
Resource    ../clamps/keywords.robot

Suite Setup     Create Session    api    ${BASE_URL}

*** Variables ***
${BASE_URL}    https://api.example.com
${TOKEN}       test-token-123

*** Test Cases ***
Update User Password
    [Documentation]    TC4 - Verify password update (RF has extra assertion vs K6)
    ${headers}=    Get Auth Headers    ${TOKEN}
    ${body}=    Create Dictionary    old_password=secret123    new_password=newpass456
    ${response}=    PUT On Session    api    /api/users/me/password    json=${body}    headers=${headers}
    Status Should Be    200    ${response}
    ${json}=    Set Variable    ${response.json()}
    Should Be Equal As Strings    ${json}[message]    Password updated
    Should Not Be Empty    ${json}[updated_at]
