*** Settings ***
Library     RequestsLibrary
Library     Collections
Resource    ../resources/common.robot
Resource    ../clamps/keywords.robot

Suite Setup     Create Session    api    ${BASE_URL}

*** Variables ***
${BASE_URL}    https://api.example.com

*** Test Cases ***
Login With Valid Credentials
    [Documentation]    TC1 - Verify login returns token
    ${body}=    Create Dictionary    username=admin    password=secret123
    ${response}=    POST On Session    api    /api/auth/login    json=${body}
    Status Should Be    200    ${response}
    ${json}=    Set Variable    ${response.json()}
    Dictionary Should Contain Key    ${json}    token

Get User Profile
    [Documentation]    TC2 - Verify authenticated user profile
    ${headers}=    Get Auth Headers    test-token-123
    ${response}=    GET On Session    api    /api/users/me    headers=${headers}
    Status Should Be    200    ${response}
    ${json}=    Set Variable    ${response.json()}
    Should Be Equal As Strings    ${json}[username]    admin
