from playwright.sync_api import Page, expect
from resources.config import BASE_URL
from clamps.helpers import get_auth_headers


def test_login_with_valid_credentials(page: Page):
    # TC1 - Verify login returns token (2 assertions)
    page.goto(f'{BASE_URL}/login')
    page.fill("input[name='username']", 'admin')
    page.fill("input[name='password']", 'secret123')
    page.click("button[type='submit']")
    expect(page).to_have_url(f'{BASE_URL}/dashboard')
    expect(page.locator('.welcome-msg')).to_be_visible()


def test_get_user_profile(page: Page):
    # TC2 - Verify user profile (1 assertion - MISMATCH vs K6:2 RF:2)
    page.goto(f'{BASE_URL}/profile')
    # username assertion intentionally omitted to create mismatch
    expect(page.locator('.profile-card')).to_be_visible()
