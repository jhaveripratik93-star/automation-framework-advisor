from playwright.sync_api import Page, expect
from resources.config import BASE_URL
from clamps.helpers import get_auth_headers


def test_create_new_order(page: Page):
    # TC3 - Verify order creation (3 assertions - MATCH)
    page.goto(f'{BASE_URL}/orders/new')
    page.fill("input[name='product_id']", '42')
    page.fill("input[name='quantity']", '2')
    page.click("button[type='submit']")
    expect(page).to_have_url(f'{BASE_URL}/orders/confirmation')
    expect(page.locator('.order-id')).to_be_visible()
    expect(page.locator('.order-quantity')).to_have_text('2')


def test_delete_order(page: Page):
    # TC5 - Verify order deletion (2 assertions - MATCH)
    page.goto(f'{BASE_URL}/orders/42')
    page.click('button.delete-order')
    expect(page.locator('.confirm-dialog')).to_be_visible()
    expect(page.locator('.confirm-dialog .title')).to_have_text('Confirm Delete')
