from playwright.sync_api import Page, expect
from resources.config import BASE_URL
from clamps.helpers import get_auth_headers


def test_update_user_password(page: Page):
    # TC4 - Verify password update (1 assertion - MISMATCH vs K6:2 RF:3)
    page.goto(f'{BASE_URL}/settings/password')
    page.fill("input[name='old_password']", 'secret123')
    page.fill("input[name='new_password']", 'newpass456')
    page.click("button[type='submit']")
    # success message and updated_at assertions intentionally omitted
    expect(page.locator('.success-banner')).to_be_visible()
