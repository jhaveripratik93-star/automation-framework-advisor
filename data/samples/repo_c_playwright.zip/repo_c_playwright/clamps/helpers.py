def get_auth_headers(token: str) -> dict:
    return {
        'Content-Type':  'application/json',
        'Authorization': f'Bearer {token}',
    }
