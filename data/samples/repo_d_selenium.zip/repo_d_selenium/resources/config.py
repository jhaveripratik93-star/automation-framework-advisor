import os

BASE_URL = os.getenv('BASE_URL', 'https://app.example.com')
TIMEOUT  = int(os.getenv('TIMEOUT', '10'))
