import pytest
from selenium.webdriver.common.by import By
from resources.config import BASE_URL
from clamps.helpers import login, get_driver


def test_update_user_password():
    # TC4 - 3 assertions (matches K6)
    driver = get_driver()
    login(driver, 'admin', 'secret123')
    driver.get(f'{BASE_URL}/settings/password')
    driver.find_element(By.NAME, 'old_password').send_keys('secret123')
    driver.find_element(By.NAME, 'new_password').send_keys('newpass456')
    driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    assert driver.find_element(By.CLASS_NAME, 'success-banner').is_displayed()
    assert driver.find_element(By.CLASS_NAME, 'success-banner').text == 'Password updated'
    assert driver.find_element(By.CLASS_NAME, 'updated-at').is_displayed()
    driver.quit()
