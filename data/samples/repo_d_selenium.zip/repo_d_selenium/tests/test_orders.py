import pytest
from selenium.webdriver.common.by import By
from resources.config import BASE_URL
from clamps.helpers import login, get_driver


def test_create_new_order():
    # TC3 - 6 assertions: 3 base + 3 inside for-loop over order items
    driver = get_driver()
    login(driver, 'admin', 'secret123')
    driver.get(f'{BASE_URL}/orders/new')
    driver.find_element(By.NAME, 'product_id').send_keys('42')
    driver.find_element(By.NAME, 'quantity').send_keys('2')
    driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    assert 'confirmation' in driver.current_url
    assert driver.find_element(By.CLASS_NAME, 'order-id').is_displayed()
    assert driver.find_element(By.CLASS_NAME, 'order-quantity').text == '2'

    items = driver.execute_script("return window.__orderItems || [{sku: 'SKU-42', price: 9.99, in_stock: true}]")
    for item in items:
        assert isinstance(item['sku'], str)    # item sku is a string
        assert item['price'] > 0               # item price is positive
        assert item['in_stock'] is True        # item is in stock
        break  # one iteration only
    driver.quit()


def test_delete_order():
    # TC5 - 2 assertions
    driver = get_driver()
    login(driver, 'admin', 'secret123')
    driver.get(f'{BASE_URL}/orders/42')
    driver.find_element(By.CSS_SELECTOR, 'button.delete-order').click()
    assert driver.find_element(By.CLASS_NAME, 'confirm-dialog').is_displayed()
    assert driver.find_element(By.CSS_SELECTOR, '.confirm-dialog .title').text == 'Confirm Delete'
    driver.quit()
