import pytest
from selenium.webdriver.common.by import By
from resources.config import BASE_URL
from clamps.helpers import login, get_driver


def test_login_with_valid_credentials():
    # TC1 - 2 assertions
    driver = get_driver()
    login(driver, 'admin', 'secret123')
    assert 'dashboard' in driver.current_url
    assert driver.find_element(By.CLASS_NAME, 'welcome-msg').is_displayed()
    driver.quit()


def test_get_user_profile():
    # TC2 - 4 assertions: 2 base + 2 inside for-loop over roles
    driver = get_driver()
    login(driver, 'admin', 'secret123')
    driver.get(f'{BASE_URL}/profile')
    assert driver.find_element(By.CLASS_NAME, 'profile-card').is_displayed()
    assert driver.find_element(By.ID, 'username').text == 'admin'

    roles = driver.execute_script("return window.__userRoles || ['user']")
    for role in roles:
        assert isinstance(role, str)                  # role is non-empty string
        assert role in ['admin', 'user', 'viewer']    # role is known value
        break  # one iteration only
    driver.quit()
