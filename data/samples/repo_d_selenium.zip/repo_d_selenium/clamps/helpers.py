from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from resources.config import BASE_URL, TIMEOUT


def get_driver():
    opts = Options()
    opts.add_argument('--headless')
    driver = webdriver.Chrome(options=opts)
    driver.implicitly_wait(TIMEOUT)
    return driver


def login(driver, username: str, password: str):
    driver.get(f'{BASE_URL}/login')
    driver.find_element(By.NAME, 'username').send_keys(username)
    driver.find_element(By.NAME, 'password').send_keys(password)
    driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
