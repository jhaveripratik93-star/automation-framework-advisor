import http from 'k6/http';
import { check, sleep } from 'k6';
import { BASE_URL } from '../resources/config.js';
import { getAuthHeaders } from '../clamps/helpers.js';

export const options = { vus: 1, duration: '10s' };

export default function () {

  const token = 'test-token-123';

  // TC3: Create new order
  const createRes = http.post(`${BASE_URL}/api/orders`, JSON.stringify({
    product_id: 42,
    quantity: 2,
  }), { headers: getAuthHeaders(token) });

  check(createRes, {
    'create order status 201': (r) => r.status === 201,
    'order id present':        (r) => r.json().order_id !== undefined,
    'quantity matches':        (r) => r.json().quantity === 2,
  });
  sleep(1);

  // TC5: Delete order
  const deleteRes = http.del(`${BASE_URL}/api/orders/42`, null, {
    headers: getAuthHeaders(token),
  });

  check(deleteRes, {
    'delete status 204':    (r) => r.status === 204,
    'body is empty':        (r) => r.body === null || r.body === '',
  });
  sleep(1);
}
