import http from 'k6/http';
import { check, sleep } from 'k6';
import { BASE_URL } from '../resources/config.js';
import { getAuthHeaders } from '../clamps/helpers.js';

export const options = { vus: 1, duration: '10s' };

export default function () {

  const token = 'test-token-123';

  // TC3: create new order
  const createRes = http.post(`${BASE_URL}/api/orders`, JSON.stringify({
    product_id: 42,
    quantity: 2,
  }), { headers: getAuthHeaders(token) });

  check(createRes, {
    'confirmation in redirect url': (r) => r.headers['Location'] !== undefined && r.headers['Location'].includes('confirmation'),
    'order-id visible':             (r) => r.json().order_id !== undefined,
    'order-quantity matches':       (r) => String(r.json().quantity) === '2',
  });

  const items = createRes.json().items || [{ sku: 'SKU-42', price: 9.99, in_stock: true }];
  for (const item of items) {
    check(item, {
      'item sku is a string':   (i) => typeof i.sku === 'string' && i.sku.length > 0,
      'item price is positive': (i) => i.price > 0,
      'item is in stock':       (i) => i.in_stock === true,
    });
    break; // assert once to keep count deterministic (3 loop assertions)
  }
  sleep(1);

  // TC5: delete order
  const deleteRes = http.del(`${BASE_URL}/api/orders/42`, null, {
    headers: getAuthHeaders(token),
  });

  check(deleteRes, {
    'confirm-dialog visible':       (r) => r.json().confirm_dialog !== undefined,
    'confirm-dialog title matches': (r) => r.json().title === 'Confirm Delete',
  });
  sleep(1);
}
