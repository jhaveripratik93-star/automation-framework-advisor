import http from 'k6/http';
import { check, sleep } from 'k6';
import { BASE_URL } from '../resources/config.js';
import { getAuthHeaders } from '../clamps/helpers.js';

export const options = { vus: 1, duration: '10s' };

export default function () {

  const token = 'test-token-123';

  // TC4: Update user password
  const updateRes = http.put(`${BASE_URL}/api/users/me/password`, JSON.stringify({
    old_password: 'secret123',
    new_password: 'newpass456',
  }), { headers: getAuthHeaders(token) });

  check(updateRes, {
    'update status 200':    (r) => r.status === 200,
    'message is success':   (r) => r.json().message === 'Password updated',
    'updated_at present':   (r) => r.json().updated_at !== undefined,
  });
  sleep(1);
}
