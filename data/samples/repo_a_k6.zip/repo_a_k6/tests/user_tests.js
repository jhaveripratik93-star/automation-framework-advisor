import http from 'k6/http';
import { check, sleep } from 'k6';
import { BASE_URL } from '../resources/config.js';
import { getAuthHeaders } from '../clamps/helpers.js';

export const options = { vus: 1, duration: '10s' };

export default function () {

  const token = 'test-token-123';

  // TC4: update user password
  const updateRes = http.put(`${BASE_URL}/api/users/me/password`, JSON.stringify({
    old_password: 'secret123',
    new_password: 'newpass456',
  }), { headers: getAuthHeaders(token) });

  check(updateRes, {
    'success-banner visible':       (r) => r.json().success_banner !== undefined,
    'success-banner text matches':  (r) => r.json().message === 'Password updated',
    'updated-at visible':           (r) => r.json().updated_at !== undefined,
  });
  sleep(1);
}
