import http from 'k6/http';
import { check, sleep } from 'k6';
import { BASE_URL } from '../resources/config.js';
import { getAuthHeaders } from '../clamps/helpers.js';

export const options = { vus: 1, duration: '10s' };

export default function () {

  // TC1: Login with valid credentials
  const loginRes = http.post(`${BASE_URL}/api/auth/login`, JSON.stringify({
    username: 'admin',
    password: 'secret123',
  }), { headers: { 'Content-Type': 'application/json' } });

  check(loginRes, {
    'login status is 200':  (r) => r.status === 200,
    'token present':        (r) => r.json().token !== undefined,
  });
  sleep(1);

  // TC2: Get user profile
  const token = loginRes.json().token;
  // TC2: Get user profile
  const profileRes = http.get(`${BASE_URL}/api/users/me`, {
    headers: getAuthHeaders(token),
  });

  check(profileRes, {
    'profile status is 200': (r) => r.status === 200,
    'username matches':      (r) => r.json().username === 'admin',
  });
  sleep(1);
}
