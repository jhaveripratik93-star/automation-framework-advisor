import http from 'k6/http';
import { check, sleep } from 'k6';
import { BASE_URL } from '../resources/config.js';
import { getAuthHeaders } from '../clamps/helpers.js';

export const options = { vus: 1, duration: '10s' };

export default function () {

  // TC1: login with valid credentials
  const loginRes = http.post(`${BASE_URL}/api/auth/login`, JSON.stringify({
    username: 'admin',
    password: 'secret123',
  }), { headers: { 'Content-Type': 'application/json' } });

  check(loginRes, {
    'dashboard in redirect url': (r) => r.headers['Location'] !== undefined && r.headers['Location'].includes('dashboard'),
    'welcome-msg visible':       (r) => r.json().welcome_msg !== undefined,
  });
  sleep(1);

  const token = loginRes.json().token;
  // TC2: get user profile
  const profileRes = http.get(`${BASE_URL}/api/users/me`, {
    headers: getAuthHeaders(token),
  });

  check(profileRes, {
    'profile-card visible': (r) => r.json().profile_card !== undefined,
    'username matches':     (r) => r.json().username === 'admin',
  });

  const roles = profileRes.json().roles || ['user'];
  for (const role of roles) {
    check(role, {
      'role is non-empty string': (r) => typeof r === 'string' && r.length > 0,
      'role is known value':      (r) => ['admin', 'user', 'viewer'].includes(r),
    });
    break; // assert once to keep count deterministic (2 loop assertions)
  }
  sleep(1);
}
