// Shared configuration for K6 test suite
export const BASE_URL = __ENV.BASE_URL || 'https://api.example.com';
export const TIMEOUT  = 5000;
