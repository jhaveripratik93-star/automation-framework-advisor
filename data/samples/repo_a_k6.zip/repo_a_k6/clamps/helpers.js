// Shared helper utilities for K6 tests
export function getAuthHeaders(token) {
  return {
    'Content-Type':  'application/json',
    'Authorization': `Bearer ${token}`,
  };
}

export function assertStatus(res, expected) {
  check(res, {
    [`status is ${expected}`]: (r) => r.status === expected,
  });
}
